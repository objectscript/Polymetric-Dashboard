(function() {
  'use strict';

  var viz = angular.module('visualizers');

  viz.controller('sensorRowCtrl', ['$scope', function($scope) {

  }]);
})();
